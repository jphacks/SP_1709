//
//  GraphViewController.swift
//  Jaguchi
//
//  Created by Kazuki Mizumaru on 2017/11/06.
//  Copyright © 2017年 乘田 悠介. All rights reserved.
//

import UIKit
import Charts

class GraphViewController: UIViewController, ChartViewDelegate {
    @IBOutlet weak var barChartView: BarChartView!
    var data = 0.0
    
    override func viewWillAppear(_ animated: Bool) {
        let filename = "data.txt"
        if let dir = FileManager.default.urls( for: .documentDirectory, in: .userDomainMask ).first {
            let path_file_name = dir.appendingPathComponent( filename )
            do {
                let text = try String( contentsOf: path_file_name, encoding: String.Encoding.utf8 )
                print( text )
                // Lへ変換
                data = Double(text)!/100
            } catch {
            }
        }

        let unitsSold = [3000.0, 4200.0, 4500.0, 4000.0, 5000.0, 5300.0, 3000.0, 4800.0, 3500.0, 2000.0, 3000.0+Double(Int(data))/10, 0.0]
        setChart(y: unitsSold)
    }
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.

    }
    func setChart(y: [Double]) {
        // プロットデータ(y軸)を保持する配列
        var dataEntries = [BarChartDataEntry]()
        var sum = 0.0

        for (i, val) in y.enumerated() {
            let dataEntry = BarChartDataEntry(x: Double(i), y: val) // X軸データは、0,1,2,...
            dataEntries.append(dataEntry)
            sum += val
        }
        let avg = sum / Double(y.count)
        
        // グラフをUIViewにセット
        let chartDataSet = BarChartDataSet(values: dataEntries, label: "")
        barChartView.data = BarChartData(dataSet: chartDataSet)
        
        // X軸のラベルを設定
        let xaxis = XAxis()
        
        xaxis.valueFormatter = BarChartFormatter()
        barChartView.xAxis.valueFormatter = xaxis.valueFormatter
        barChartView.xAxis.labelPosition = .bottom
        barChartView.xAxis.labelFont = UIFont.systemFont(ofSize: 12.0)
        barChartView.xAxis.labelCount = 12
        barChartView.xAxis.drawGridLinesEnabled = false
        barChartView.rightAxis.enabled = false
        barChartView.scaleXEnabled = false
        barChartView.scaleYEnabled = false
        
        // グラフの色
        chartDataSet.colors = [UIColor(red: 0/255, green: 0/255, blue: 255/255, alpha: 1)]
        // グラフの背景色
        barChartView.backgroundColor = UIColor(red: 255/255, green: 255/255, blue: 255/255, alpha: 1)
        // グラフの棒をニョキッとアニメーションさせる
        barChartView.animate(xAxisDuration: 1.0, yAxisDuration: 1.0)
        // 横に赤いボーダーラインを描く
        barChartView.leftAxis.addLimitLine(ChartLimitLine(limit: avg, label: "平均使用量"))
        // グラフの説明
        barChartView.chartDescription?.text = ""
        // グラフの凡例非表示
        barChartView.legend.enabled = false
    }
    
    func readTextFile(fileURL: URL) {
        do {
            let text = try String(contentsOf: fileURL, encoding: String.Encoding.utf8)
            
            // 行番号
            var lineNum = 1
            
            text.enumerateLines(invoking: {
                line, stop in
                print("\(lineNum): \(line)")
                lineNum += 1
            })
        } catch let error as NSError {
            print("failed to read: \(error)")
        }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

public class BarChartFormatter: NSObject, IAxisValueFormatter{
    // x軸のラベル
    var months: [String]! = ["1月", "2月", "3月", "4月", "5月", "6月", "7月", "8月", "9月", "10月", "11月", "12月"]
    
    public func stringForValue(_ value: Double, axis: AxisBase?) -> String {
        return months[Int(value)]
    }
}
