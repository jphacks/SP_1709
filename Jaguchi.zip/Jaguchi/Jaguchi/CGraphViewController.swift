//
//  CGraphViewController.swift
//  Jaguchi
//
//  Created by Kazuki Mizumaru on 2017/11/06.
//  Copyright © 2017年 乘田 悠介. All rights reserved.
//

import UIKit
import Charts

class CGraphViewController: UIViewController {
    @IBOutlet weak var pieChartView: PieChartView!
    var data = 0.0
    
    override func viewWillAppear(_ animated: Bool) {
        let filename = "data.txt"
        if let dir = FileManager.default.urls( for: .documentDirectory, in: .userDomainMask ).first {
            let path_file_name = dir.appendingPathComponent( filename )
            do {
                let text = try String( contentsOf: path_file_name, encoding: String.Encoding.utf8 )
                print( text )
                // Lへ変換
                data = Double(text)!/100
            } catch {
            }
        }
        let item = ["キッチン", "風呂"]
        let unitsSold = [10.0+Double(Int(data))/10, 40.0]
        setChart(dataPoints: item, values: unitsSold)
    }
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.

    }
    func setChart(dataPoints: [String], values: [Double]) {
        
        var dataEntries: [PieChartDataEntry] = []
        var sum = 0.0

        for i in 0..<dataPoints.count {
            let dataEntry = PieChartDataEntry(value: values[i], label: dataPoints[i])
            dataEntries.append(dataEntry)
            sum += values[i]
        }
        
        let pieChartDataSet = PieChartDataSet(values: dataEntries, label: "")
        let pieChartData = PieChartData(dataSet: pieChartDataSet)
        pieChartView.data = pieChartData
        pieChartView.animate(xAxisDuration: 1.0, yAxisDuration: 1.0)
        
        // centerTextのフォント変更
        let myAttribute = [ NSAttributedStringKey.font: UIFont.systemFont(ofSize: 30.0) ]
        let myAttrString = NSAttributedString(string: String(sum)+"L", attributes: myAttribute)
        pieChartView.centerAttributedText = myAttrString

        var colors: [UIColor] = []
        
        // jaguchi1 color
        colors.append(#colorLiteral(red: 0.0003798464472, green: 0.05909875461, blue: 1, alpha: 1))
        // jaguchi2 color
        colors.append(#colorLiteral(red: 0.2831189558, green: 0.6165723081, blue: 0.8549019694, alpha: 1))
        
        pieChartDataSet.colors = colors
        // グラフの説明
        pieChartView.chartDescription?.text = ""
        // グラフの凡例非表示
        pieChartView.legend.enabled = false

    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
