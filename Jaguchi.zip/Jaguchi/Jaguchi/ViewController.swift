//
//  ViewController.swift
//  Jaguchi
//
//  Created by 乘田 悠介 on 2017/10/23.
//  Copyright © 2017年 乘田 悠介. All rights reserved.
//

import UIKit
import CoreBluetooth
import Speech

class ViewController: UIViewController, CBCentralManagerDelegate, CBPeripheralDelegate {

    var centralManager: CBCentralManager!
    var BLEPeripheral: CBPeripheral!
    let localname = "GENUINO 101-CCAA"
    var mCharacteristic: CBCharacteristic?
    private let speechRecognizer = SFSpeechRecognizer(locale: Locale(identifier: "ja-JP"))!
    private var recognitionRequest: SFSpeechAudioBufferRecognitionRequest?
    private var recognitionTask: SFSpeechRecognitionTask?
    private let audioEngine = AVAudioEngine()
    private var text = ""
    var date: Date?
    var time: Double = 0.0
    let mlPerSecond: Double = 100.0
    var sum: Double = 0.0
    
    @IBOutlet weak var sumLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        sumLabel.text = "\(Int(sum))"
        //CBCentralManagerを初期化
        //centralManagerDidUpdateStateで状態変化が取得できます
        centralManager = CBCentralManager(delegate: self, queue: nil)
        try! startRecording()
    }
    
    private func startRecording() throws {
        
        // Cancel the previous task if it's running.
        if let recognitionTask = recognitionTask {
            recognitionTask.cancel()
            self.recognitionTask = nil
        }
        
        let audioSession = AVAudioSession.sharedInstance()
        try audioSession.setCategory(AVAudioSessionCategoryRecord)
        try audioSession.setMode(AVAudioSessionModeMeasurement)
        try audioSession.setActive(true, with: .notifyOthersOnDeactivation)
        
        recognitionRequest = SFSpeechAudioBufferRecognitionRequest()
        
        let inputNode = audioEngine.inputNode
        guard let recognitionRequest = recognitionRequest else { fatalError("Unable to created a SFSpeechAudioBufferRecognitionRequest object") }
        
        // Configure request so that results are returned before audio recording is finished
        recognitionRequest.shouldReportPartialResults = true
        
        // A recognition task represents a speech recognition session.
        // We keep a reference to the task so that it can be cancelled.
        recognitionTask = speechRecognizer.recognitionTask(with: recognitionRequest) { result, error in
            var isFinal = false
            
            if let result = result {
                self.text = result.bestTranscription.formattedString
                print(self.text)
                if (self.text.contains("開けて") || self.text.contains("あけて") || self.text.contains("閉じて") || self.text.contains("閉めて") || self.text.contains("しめて") || self.text.contains("とじて") || self.text.contains("ミリリットル")) {
                    self.recognitionRequest?.endAudio()
                }
                isFinal = result.isFinal
            }
            
            if (error != nil || isFinal) {
                if (self.text.contains("開けて") || self.text.contains("あけて")) {
                    self.turnOn()
                } else if (self.text.contains("閉じて") || self.text.contains("閉めて") || self.text.contains("しめて") || self.text.contains("とじて")) {
                    self.turnOff()
                } else if (self.text.contains("ミリリットル")) {
                    let endIndex = self.text.index(of: "ミ")
                    let startIndex = self.text.index(endIndex!, offsetBy: -3)
                    let range = startIndex ..< endIndex!
                    let substr = self.text[range]
                    print(substr + "ml")
                    let amountOfWater = Double(substr)
                    if let amount = amountOfWater {
                        self.setAmount(amount)
                    }
                }
                
                self.audioEngine.stop()
                inputNode.removeTap(onBus: 0)
                
                self.recognitionRequest = nil
                self.recognitionTask = nil
                
                try! self.startRecording()
            }
        }
        
        let recordingFormat = inputNode.outputFormat(forBus: 0)
        inputNode.installTap(onBus: 0, bufferSize: 1024, format: recordingFormat) { (buffer: AVAudioPCMBuffer, when: AVAudioTime) in
            self.recognitionRequest?.append(buffer)
        }
        
        audioEngine.prepare()
        try audioEngine.start()
    }

    //セントラルマネージャーの状態変化を取得
    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        switch (central.state) {
            
        case .poweredOff:
            print("Bluetoothの電源がOff")
        case .poweredOn:
            print("Bluetoothの電源はOn")
            //ペリフェラルのスキャン開始
            centralManager.scanForPeripherals(withServices: nil, options:nil)
            
        case .resetting:
            print("レスティング状態")
        case .unauthorized:
            print("非認証状態")
        case .unknown:
            print("不明")
        case .unsupported:
            print("非対応")
        
        }
    }

    //スキャン結果を受け取る
    internal func centralManager(_ central: CBCentralManager, didDiscover peripheral: CBPeripheral, advertisementData: [String : Any], rssi RSSI: NSNumber) {
        //スキャンが完了しない場合は、peripheral.nameが違っているかもしれません。
        //ここでperipheral.nameを確認してください。
        if let peripheralname = peripheral.name {
            print("\(peripheralname)")
            
            if (peripheralname == localname) {
                BLEPeripheral = peripheral
                //BLE Nanoのスキャンに成功したら接続
                centralManager.connect(BLEPeripheral, options: nil)
                centralManager.stopScan()
                print("\(peripheralname)をスキャン完了!")
            }
        }
    }
    
    //ペリフェラルに接続完了
    internal func centralManager(_ central: CBCentralManager, didConnect peripheral: CBPeripheral) {
        BLEPeripheral.delegate = self
        //接続できたらサービスを探索
        BLEPeripheral.discoverServices(nil)
    }
    
    //ペリフェラルに接続失敗
    internal func centralManager(_ central: CBCentralManager, didFailToConnect peripheral: CBPeripheral, error: Error?) {
        print("接続失敗")
    }
    
    //サービスの探索結果を受け取る
    func peripheral(_ peripheral: CBPeripheral, didDiscoverServices error: Error?) {
        if let error = error {
            print("エラー：\(error)")
            return
        }
        
        if !((peripheral.services?.count)! > 0) {
            print("サービスがありません")
        } else {
            let services = peripheral.services!
            print("\(services) サービスが見つかりました")
            //サービスが見つかったら、キャラクタリスティックを探索
            peripheral.discoverCharacteristics(nil, for: services[0])
        }
    }
    
    //キャラクリスティックの探索結果を受け取る
    func peripheral(_ peripheral: CBPeripheral, didDiscoverCharacteristicsFor service: CBService, error: Error?) {
        if let error = error {
            print("エラー：\(error)")
            return
        }
        
        if !((service.characteristics?.count)! > 0) {
            print("キャラクタリスティックがありません")
            return
        }
        
        let characteristics = service.characteristics!
        let characteristic = characteristics[0]
        print("\(characteristics) キャラクタリスティックが見つかりました")
        mCharacteristic = characteristic

    }
    
    @IBAction func turnOn() {
        self.sendValue("0")
        date = Date()
    }
    
    @IBAction func turnOff() {
        self.sendValue("1")
        if let timeInterval = date?.timeIntervalSinceNow {
            time = -timeInterval
            print("\(time)" + "秒")
            print("\(time * mlPerSecond)" + "ml")
        }
        date = nil
        self.sumAmount(time * mlPerSecond)
    }
    
    func setAmount(_ amount: Double) {
        let numOfSeconds = amount / self.mlPerSecond
        self.sendValue("0")
        DispatchQueue.main.asyncAfter(deadline: .now() + numOfSeconds) {
            self.sendValue("1")
        }
        self.sumAmount(amount)
    }

    func sumAmount(_ amount: Double) {
        sum += amount
        sumLabel.text = "\(Int(sum))"
    }
    
    private func sendValue(_ value: String) {
        if (mCharacteristic != nil) {
            //キャラクタリスティックに値を書き込む
            let data: Data! = value.data(using: String.Encoding.utf8,allowLossyConversion:true)
            BLEPeripheral.writeValue(data, for: mCharacteristic!, type: CBCharacteristicWriteType.withResponse)
        } else {
            print("接続しなおしてください")
        }
    }
    
    //書き込み結果の取得
    func peripheral(_ peripheral: CBPeripheral, didWriteValueFor characteristic: CBCharacteristic, error: Error?) {
        if let error = error {
            print("エラー：\(error)")
            return
        }
        print("書き込み成功")
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

