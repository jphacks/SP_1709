//
//  ViewController.swift
//  Jaguchi
//
//  Created by 乘田 悠介 on 2017/10/23.
//  Modified by Kazuki Mizumaru on 2017/11/4
//  Copyright © 2017年 乘田 悠介. All rights reserved.
//

import UIKit
import CoreBluetooth
import Speech

class ViewController: UIViewController, CBCentralManagerDelegate, CBPeripheralDelegate {
    @IBOutlet weak var oldButton: UIButton!
    @IBOutlet weak var newButton: UIButton!
    @IBOutlet weak var onButton: UIButton!
    @IBOutlet weak var offButton: UIButton!
    @IBOutlet weak var label: UILabel!
    @IBOutlet weak var unitLabel: UILabel!
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var sumLabel: UILabel!
    
    var centralManager: CBCentralManager!
    var BLEPeripheral: CBPeripheral!
    let localname = "GENUINO 101-CCAA"
    var mCharacteristic: CBCharacteristic?
    private let speechRecognizer = SFSpeechRecognizer(locale: Locale(identifier: "ja-JP"))!
    private var recognitionRequest: SFSpeechAudioBufferRecognitionRequest?
    private var recognitionTask: SFSpeechRecognitionTask?
    private let audioEngine = AVAudioEngine()
    private var text = ""
    var date: Date?
    var time: Double = 0.0
    let mlPerSecond: Double = 130.0
    var sum: Double = 0.0
    var isOpen: Bool = false
    var isBusy = false


    override func viewDidLoad() {
        super.viewDidLoad()
        // ラベルに初期値を設定
        sumLabel.textAlignment = NSTextAlignment.right
        sumLabel.text = "\(Int(sum))"
        // デバッグ用ボタンを隠す
        onButton.isHidden = true
        offButton.isHidden = true
        // ラベル非表示
        unitLabel.isHidden = true
        sumLabel.isHidden = true
        //CBCentralManagerを初期化
        //centralManagerDidUpdateStateで状態変化が取得できます
        centralManager = CBCentralManager(delegate: self, queue: nil)
    }
    
    // jaguchi1が選択されたときに呼び出される
    @IBAction func selectOldType(){
        // jaguchiOff.pngの表示
        let image = UIImage(named: "jaguchiOff")
        imageView.image = image
        // arduino制御用信号送信
        sendValue("0")
        // jaguchi選択不可
        oldButton.isEnabled = false
        newButton.isEnabled = false
        // デバッグ用ボタン表示
        onButton.isHidden = false
        offButton.isHidden = false
        // ラベル表示
        unitLabel.isHidden = false
        sumLabel.isHidden = false
        // 音声認識開始
        try! startRecording()
    }
    
    // jaguchi2が選択されたときに呼び出される
    @IBAction func selectNewType(){
        // jaguchiOff2.pngの表示
        let image = UIImage(named: "jaguchiOff2")
        imageView.image = image
        // arduino制御用信号送信
        sendValue("1")
        // jaguchi選択不可
        oldButton.isEnabled = false
        newButton.isEnabled = false
        // デバッグ用ボタンを表示
        //onButton.isHidden = false
        //offButton.isHidden = false
        // ラベル表示
        unitLabel.isHidden = false
        sumLabel.isHidden = false
        // 音声認識開始
        try! startRecording()
    }
    
    private func startRecording() throws {
        print("start")
        // Cancel the previous task if it's running.
        if let recognitionTask = recognitionTask {
            recognitionTask.cancel()
            self.recognitionTask = nil
            print("cancel")
        }
        
        let audioSession = AVAudioSession.sharedInstance()
        try audioSession.setCategory(AVAudioSessionCategoryRecord)
        try audioSession.setMode(AVAudioSessionModeMeasurement)
        try audioSession.setActive(true, with: .notifyOthersOnDeactivation)
        
        recognitionRequest = SFSpeechAudioBufferRecognitionRequest()
        
        let inputNode = audioEngine.inputNode
        guard let recognitionRequest = recognitionRequest else { fatalError("Unable to created a SFSpeechAudioBufferRecognitionRequest object") }
        
        // Configure request so that results are returned before audio recording is finished
        recognitionRequest.shouldReportPartialResults = true
        
        // A recognition task represents a speech recognition session.
        // We keep a reference to the task so that it can be cancelled.
        
        recognitionTask = speechRecognizer.recognitionTask(with: recognitionRequest) { result, error in
            var isFinal = false

            print("task")
            
            if let result = result {
                self.text = result.bestTranscription.formattedString
                print(self.text)
                if (self.isOpen) {
                    if (self.text.contains("閉じて") || self.text.contains("閉めて") || self.text.contains("しめて") || self.text.contains("とじて")) {
                        self.turnOff()
                    }
                } else {
                    if (self.text.contains("開けて") || self.text.contains("あけて")) {
                        self.turnOn()
                    } else if (self.text.contains("ミリ") || self.text.contains("CC")) {
                        if (!self.isBusy){
                            self.isBusy = true
                            let splitNumbers = (self.text.components(separatedBy: NSCharacterSet.decimalDigits.inverted))
                            let number = splitNumbers.joined()
                            let substr = String(number)
                            print(substr + "ml")
                            let amountOfWater = Double(substr)
                            if let amount = amountOfWater {
                                self.setAmount(amount)
                            }
                        }
                    } else if (self.text.contains("リットル")) {
                        if (!self.isBusy){
                            self.isBusy = true
                            let splitNumbers = (self.text.components(separatedBy: NSCharacterSet.decimalDigits.inverted))
                            let number = splitNumbers.joined()
                            var str = String(number)

                            if number.count == 2 {
                                str = str[..<str.index(str.startIndex, offsetBy: 1)] + "." + str[str.index(str.endIndex, offsetBy: -1)...]
                            }
                            let amountOfWater = Double(str)
                            if let amount = amountOfWater {
                                print(String(Double(str)!*1000) + "ml")
                                self.setAmount(amount*1000)
                            }
                        }
                    }
                }
                self.recognitionRequest?.endAudio()
                isFinal = result.isFinal
            }
            
            if (error != nil || isFinal) {
                print("終わり")
                self.audioEngine.stop()
                inputNode.removeTap(onBus: 0)
                self.recognitionRequest = nil
                self.recognitionTask = nil
                
                if (self.centralManager.state == .poweredOn) {
                    try! self.startRecording()
                }
            }
        }
        
        let recordingFormat = inputNode.outputFormat(forBus: 0)
        inputNode.installTap(onBus: 0, bufferSize: 1024, format: recordingFormat) { (buffer: AVAudioPCMBuffer, when: AVAudioTime) in
            self.recognitionRequest?.append(buffer)
        }
        
        audioEngine.prepare()
        try audioEngine.start()
    }
    
    @IBAction func turnOn() {
        // arduino制御用信号送信
        self.sendValue("0")
        date = Date()
        self.isOpen = true
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
            self.label.text = ""
        }
        // jaguchiOn.pngを表示
        let image = UIImage(named: "jaguchiOn")
        imageView.image = image
    }
    
    @IBAction func turnOff() {
        self.sendValue("1")
        if let timeInterval = date?.timeIntervalSinceNow {
            time = -timeInterval
            print("\(time)" + "秒")
            print("\(time * mlPerSecond)" + "ml")
        }
        date = nil
        self.sumAmount(time * mlPerSecond)
        self.isOpen = false
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
            self.label.text = ""
        }
        // jaguchiOff.pngを表示
        let image = UIImage(named: "jaguchiOff")
        imageView.image = image
    }
    
    func setAmount(_ amount: Double) {
        let numOfSeconds = amount / self.mlPerSecond
        self.sendValue("0")
        var image = UIImage(named: "jaguchiOn")
        imageView.image = image
        
        DispatchQueue.main.asyncAfter(deadline: .now() + numOfSeconds) {
            self.sendValue("1")
            image = UIImage(named: "jaguchiOff")
            self.imageView.image = image
            self.isBusy = false
        }
        self.sumAmount(amount)
    }

    func sumAmount(_ amount: Double) {
        sum += amount
        sumLabel.text = "\(Int(amount))"
        
        print("sumsum:"+String(sum))
        // アプリ内部に一時的にデータ保存
        let filename = "data.txt"
        let text = String(sum)
        
        if let dir = FileManager.default.urls( for: .documentDirectory, in: .userDomainMask ).first {
            let path_file_name = dir.appendingPathComponent( filename )
            do {
                try text.write( to: path_file_name, atomically: false, encoding: String.Encoding.utf8 )
            } catch {
            }
        }
    }
    
    //セントラルマネージャーの状態変化を取得
    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        switch (central.state) {
            
        case .poweredOff:
            print("Bluetoothの電源がOff")
            // ラベル・ボタンを非表示
            unitLabel.isHidden = true
            sumLabel.isHidden = true
            oldButton.isHidden = true
            newButton.isHidden = true
            self.recognitionRequest?.endAudio()
            label.text = "BluetoothをONにして下さい"
        case .poweredOn:
            print("Bluetoothの電源はOn")
            label.text = ""
            // ボタンを表示
            oldButton.isHidden = false
            newButton.isHidden = false
            oldButton.isEnabled = true
            newButton.isEnabled = true
            //ペリフェラルのスキャン開始
            centralManager.scanForPeripherals(withServices: nil, options:nil)
        case .resetting:
            print("レスティング状態")
        case .unauthorized:
            print("非認証状態")
        case .unknown:
            print("不明")
        case .unsupported:
            print("非対応")
        }
    }
    
    //スキャン結果を受け取る
    internal func centralManager(_ central: CBCentralManager, didDiscover peripheral: CBPeripheral, advertisementData: [String : Any], rssi RSSI: NSNumber) {
        
        if let peripheralname = peripheral.name {
            print("\(peripheralname)")
            
            if (peripheralname == localname) {
                BLEPeripheral = peripheral
                //BLE Nanoのスキャンに成功したら接続
                centralManager.connect(BLEPeripheral, options: nil)
                centralManager.stopScan()
                print("\(peripheralname)をスキャン完了!")
            }
        }
    }
    
    //ペリフェラルに接続完了
    internal func centralManager(_ central: CBCentralManager, didConnect peripheral: CBPeripheral) {
        BLEPeripheral.delegate = self
        //接続できたらサービスを探索
        BLEPeripheral.discoverServices(nil)
    }
    
    internal func centralManager(_ central: CBCentralManager, didDisconnectPeripheral peripheral: CBPeripheral, error: Error?) {
        self.label.text = "接続が切れました"
        oldButton.isHidden = true
        newButton.isHidden = true
        onButton.isHidden = true
        offButton.isHidden = true
        self.recognitionRequest?.endAudio()
    }
    
    //ペリフェラルに接続失敗
    internal func centralManager(_ central: CBCentralManager, didFailToConnect peripheral: CBPeripheral, error: Error?) {
        print("接続失敗")
    }
    
    //サービスの探索結果を受け取る
    func peripheral(_ peripheral: CBPeripheral, didDiscoverServices error: Error?) {
        if let error = error {
            print("エラー：\(error)")
            return
        }
        
        if !((peripheral.services?.count)! > 0) {
            print("サービスがありません")
        } else {
            let services = peripheral.services!
            print("\(services) サービスが見つかりました")
            //サービスが見つかったら、キャラクタリスティックを探索
            peripheral.discoverCharacteristics(nil, for: services[0])
        }
    }
    
    //キャラクリスティックの探索結果を受け取る
    func peripheral(_ peripheral: CBPeripheral, didDiscoverCharacteristicsFor service: CBService, error: Error?) {
        if let error = error {
            print("エラー：\(error)")
            return
        }
        
        if !((service.characteristics?.count)! > 0) {
            print("キャラクタリスティックがありません")
            return
        }
        
        let characteristics = service.characteristics!
        let characteristic = characteristics[0]
        print("\(characteristic) キャラクタリスティックが見つかりました")
        mCharacteristic = characteristic
        print("接続完了")
        oldButton.isHidden = false
        newButton.isHidden = false
    }
    
    private func sendValue(_ value: String) {
        if (mCharacteristic != nil) {
            //キャラクタリスティックに値を書き込む
            let data: Data! = value.data(using: String.Encoding.utf8,allowLossyConversion:true)
            BLEPeripheral.writeValue(data, for: mCharacteristic!, type: CBCharacteristicWriteType.withResponse)
        } else {
            print("接続しなおしてください")
        }
    }
    
    //書き込み結果の取得
    func peripheral(_ peripheral: CBPeripheral, didWriteValueFor characteristic: CBCharacteristic, error: Error?) {
        if let error = error {
            print("エラー：\(error)")
            return
        }
        print("書き込み成功")
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
